import { useState, useRef, useEffect } from 'react'
import { DOCUMENTS } from './data/documents.js'
import { useChat } from './hooks/useChat.js'
import Header from './components/Header.jsx'
import Sidebar from './components/Sidebar.jsx'
import Message from './components/Message.jsx'
import ThinkingIndicator from './components/ThinkingIndicator.jsx'
import WelcomeCard from './components/WelcomeCard.jsx'
import SuggestionChips from './components/SuggestionChips.jsx'
import InputBar from './components/InputBar.jsx'
import styles from './App.module.css'

export default function App() {
  const [activeDocId, setActiveDocId] = useState('all')
  const { messages, isLoading, error, sendMessage, clearChat } = useChat(activeDocId)
  const messagesEndRef = useRef(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  const handleSend = (text) => {
    sendMessage(text)
  }

  const handleChipSelect = (question) => {
    sendMessage(question)
  }

  return (
    <div className={styles.layout}>
      <div className={styles.shell}>
        <Header docCount={Object.keys(DOCUMENTS).length} />

        <div className={styles.body}>
          <Sidebar activeDocId={activeDocId} onSelectDoc={setActiveDocId} />

          <main className={styles.chatArea}>
            <div className={styles.messages} role="log" aria-live="polite" aria-label="Conversation">
              {messages.length === 0 && <WelcomeCard />}

              {messages.map(msg => (
                <Message key={msg.id} message={msg} />
              ))}

              {isLoading && <ThinkingIndicator />}

              {error && (
                <div className={styles.errorBanner} role="alert">
                  <i className="ti ti-alert-triangle" aria-hidden="true" />
                  <span>{error}</span>
                  <button className={styles.dismissBtn} onClick={() => clearChat()} aria-label="Dismiss error">
                    <i className="ti ti-x" aria-hidden="true" />
                  </button>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            <SuggestionChips
              onSelect={handleChipSelect}
              visible={messages.length === 0 && !isLoading}
            />

            <InputBar onSend={handleSend} isLoading={isLoading} />
          </main>
        </div>
      </div>
    </div>
  )
}

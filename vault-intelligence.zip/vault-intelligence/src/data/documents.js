export const DOCUMENTS = {
  q1: {
    id: 'q1',
    name: 'Q1 2024 Earnings Report',
    meta: 'Revenue, EPS, guidance',
    iconClass: 'ti-chart-bar',
    colorClass: 'blue',
    content: `Q1 2024 EARNINGS REPORT — FIFTH NATIONAL BANK
Net Revenue: $847M (up 12.3% YoY from $754M)
Net Interest Income: $612M
Non-Interest Income: $235M
EPS (diluted): $2.84 (vs $2.41 prior year, +17.8%)
Return on Equity: 14.2%
Loan Portfolio Growth: +8.6% YoY ($42.1B total)
Deposit Growth: +5.1% YoY ($58.3B total)
Provision for Credit Losses: $94M (up from $71M)
Net Interest Margin: 3.42% (down from 3.61% prior year)
Efficiency Ratio: 54.3%
FY2024 Guidance: Revenue $3.3B–$3.45B; EPS $11.20–$11.60
Capital Ratios: CET1 11.8%, Tier 1 13.1%
Average Loans Outstanding: $38.9B
Average Deposits: $55.5B
Non-Performing Assets: 0.42% of total assets
Charge-off Rate: 0.38% annualized`
  },
  policy: {
    id: 'policy',
    name: 'Loan Policy Manual',
    meta: 'Eligibility, rates, terms',
    iconClass: 'ti-file-text',
    colorClass: 'gold',
    content: `LOAN POLICY MANUAL — REV. 2024.1
Personal Loans: Min FICO 640, max $50,000, terms 12–84 months, APR 7.99%–24.99%
Auto Loans (new): Min FICO 620, max $100,000, up to 84 months, APR 5.49%–14.99%
Auto Loans (used): Min FICO 640, max $75,000, up to 72 months, APR 6.49%–18.99%
Home Equity Loan: Min FICO 680, max 85% CLTV, $10K–$500K, 5–30 yr, fixed
HELOC: Min FICO 660, max 80% CLTV, draw period 10 yr, repayment 20 yr, variable APR
Mortgage (Conventional): Min FICO 620, min 3% down, max loan $766,550 conforming
Mortgage (Jumbo): Min FICO 720, min 20% down, max $3M, manual underwriting required
Business Loans: Min 2 yr in business, min $250K annual revenue, personal guarantee required
Debt-to-Income ratio max: 43% standard, 50% with compensating factors
Documentation: 2 yr W-2 or tax returns, 2 mo bank statements, employment verification
Appraisal: Required for all real estate secured loans over $250,000
Rate Lock: Available 30, 45, 60 days; float-down option available on 45+ day locks`
  },
  compliance: {
    id: 'compliance',
    name: 'AML Compliance Guide',
    meta: 'KYC, SAR, risk tiers',
    iconClass: 'ti-shield-check',
    colorClass: 'coral',
    content: `AML / BSA COMPLIANCE GUIDE — Q2 2024
Currency Transaction Report (CTR): Required for cash transactions $10,000+
Suspicious Activity Report (SAR): Required within 30 days of detecting suspicious activity; $5,000 threshold for known customers, $2,000 for unknown
Structuring (Smurfing): Illegal to break large transactions to avoid CTR; flag any pattern suggesting structuring
KYC Requirements: Government-issued ID, date of birth, SSN or EIN, beneficial ownership for entities >25% ownership
Customer Risk Tiers: Low (standard retail, verified), Medium (high-cash businesses, PEPs), High (offshore accounts, sanctions adjacent)
Enhanced Due Diligence (EDD): Required for High-risk customers; annual review, source of funds documentation
Office of Foreign Assets Control (OFAC): Screen all new customers and transactions against SDN list; no de minimis threshold
Politically Exposed Persons (PEPs): Automatic Medium or High risk; EDD mandatory
Record Retention: 5 years for transaction records, 5 years for SARs, permanent for CTRs filed
Training: All customer-facing staff must complete AML certification annually
Beneficial Ownership Rule: Collect ownership info for legal entities with 25%+ individual owners
FinCEN Filing: All SARs and CTRs submitted via BSA E-Filing System within mandated timeframes`
  },
  rates: {
    id: 'rates',
    name: 'Rate Sheet — May 2025',
    meta: 'CD, savings, mortgage',
    iconClass: 'ti-percentage',
    colorClass: 'green',
    content: `PRODUCT RATE SHEET — MAY 2025
SAVINGS & DEPOSITS:
High-Yield Savings: 4.75% APY (min $1,000 balance)
Standard Savings: 0.45% APY
Money Market (Tier 1, <$10K): 3.85% APY
Money Market (Tier 2, $10K–$99K): 4.25% APY
Money Market (Tier 3, $100K+): 4.65% APY
CDs: 3-month 4.50% | 6-month 4.85% | 12-month 5.10% | 24-month 4.75% | 36-month 4.40%
Jumbo CDs ($100K+): Add 0.10% to above rates
IRA CDs: Same as standard CD rates; Roth and Traditional IRA eligible
MORTGAGES (as of 2025-05-01):
30-year Fixed: 6.875% (APR 6.94%)
20-year Fixed: 6.625% (APR 6.70%)
15-year Fixed: 6.25% (APR 6.33%)
10/1 ARM: 6.50% initial (APR 7.12% after adjustment)
5/1 ARM: 6.125% initial (APR 7.20% after adjustment)
FHA 30-year: 6.625% (APR 7.49% incl. MIP)
VA Loan: 6.375% (APR 6.44%)
LOANS:
Prime Rate: 8.50%
Personal Loan: 7.99%–24.99% APR
Auto (new): 5.49%–14.99% APR
HELOC Current Rate: Prime + 0.25% = 8.75% APR (variable)
Home Equity Loan (fixed): 7.99%–9.99% APR`
  },
  invest: {
    id: 'invest',
    name: 'Investment Portfolio Policy',
    meta: 'Allocation, risk, ESG',
    iconClass: 'ti-trending-up',
    colorClass: 'purple',
    content: `INVESTMENT PORTFOLIO POLICY — 2024
Approved Asset Classes: US Treasuries, Agency MBS, Investment-grade corporates (BBB- or higher), Municipal bonds, Equity index funds (for trust accounts)
Duration Limits: Securities portfolio max 5.5 yr avg duration; held-to-maturity max 10 yr individual
Concentration Limits: Single issuer max 5% of tier 1 capital (except UST/Agency); single sector max 25%
Credit Quality: Min 60% of portfolio must be rated A or better; no speculative-grade (below BBB-)
ESG Policy: New investments screened for ESG ratings; min 30% of new fixed-income purchases must meet ESG criteria by 2025
Liquidity Reserve: Min 15% of portfolio in Level 1 HQLA (cash, UST); min 25% in Level 1+2 combined
Prohibited Investments: Crypto assets, leveraged/inverse ETFs, CDOs, CLOs rated below AAA, direct commodity holdings
Reporting: Monthly mark-to-market P&L, quarterly board review, annual stress test (200bps parallel shift)
Benchmark: Bloomberg Aggregate Bond Index for fixed income; 60/40 blended for balanced portfolios
Derivatives: Interest rate swaps permitted for hedging only; no speculative derivative positions
Rebalancing: Triggered when any asset class drifts >5% from target allocation`
  }
}

export const ALL_DOCS_COMBINED = Object.values(DOCUMENTS)
  .map(d => d.content)
  .join('\n\n---\n\n')

export const SUGGESTED_QUESTIONS = [
  "What's the current 30-year fixed mortgage rate?",
  "What's the minimum FICO score for a home equity loan?",
  "How did Q1 net revenue compare to last year?",
  "What's the SAR filing threshold for known customers?",
  "Which CD term offers the best rate right now?",
  "What are the DTI limits for mortgage approval?",
  "What investments are prohibited under portfolio policy?",
  "What KYC documents are required to open an account?",
]

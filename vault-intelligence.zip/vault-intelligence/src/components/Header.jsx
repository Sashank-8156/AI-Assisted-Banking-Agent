import styles from './Header.module.css'

export default function Header({ docCount }) {
  return (
    <header className={styles.header}>
      <div className={styles.left}>
        <div className={styles.vaultIcon} aria-hidden="true">
          <i className="ti ti-building-bank" />
        </div>
        <div>
          <h1 className={styles.title}>Vault Intelligence</h1>
          <p className={styles.subtitle}>AI Banking Assistant · Doc-Grounded</p>
        </div>
      </div>
      <div className={styles.statusPill} role="status" aria-label={`${docCount} documents loaded`}>
        <span className={styles.pulse} aria-hidden="true" />
        {docCount} documents loaded
      </div>
    </header>
  )
}

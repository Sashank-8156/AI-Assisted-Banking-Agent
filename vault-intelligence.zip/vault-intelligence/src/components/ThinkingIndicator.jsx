import styles from './ThinkingIndicator.module.css'

export default function ThinkingIndicator() {
  return (
    <div className={styles.wrapper} role="status" aria-label="AI is thinking">
      <div className={styles.avatar} aria-hidden="true">
        <i className="ti ti-building-bank" />
      </div>
      <div className={styles.bubble}>
        <span className={styles.text}>Analyzing documents</span>
        <span className={styles.dots} aria-hidden="true">
          <span /><span /><span />
        </span>
      </div>
    </div>
  )
}

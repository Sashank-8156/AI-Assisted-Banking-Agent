import styles from './Message.module.css'

function SourceTag({ doc }) {
  return (
    <span className={styles.sourceTag} title={doc.name}>
      <i className="ti ti-file-text" aria-hidden="true" />
      {doc.name.split('—')[0].trim()}
    </span>
  )
}

export default function Message({ message }) {
  const isUser = message.role === 'user'

  const formattedContent = message.content
    .split('\n\n')
    .filter(p => p.trim())
    .map((para, i) => (
      <p key={i} className={styles.para}>
        {para.replace(/\n/g, ' ')}
      </p>
    ))

  return (
    <div className={`${styles.msg} ${isUser ? styles.user : styles.ai}`}>
      <div className={`${styles.avatar} ${isUser ? styles.avatarUser : styles.avatarAi}`} aria-hidden="true">
        {isUser
          ? 'You'
          : <i className="ti ti-building-bank" />
        }
      </div>

      <div className={`${styles.bubble} ${isUser ? styles.bubbleUser : styles.bubbleAi}`}>
        {formattedContent}

        {!isUser && message.sources?.length > 0 && (
          <div className={styles.sourceTags} aria-label="Source documents">
            <span className={styles.sourceLabel}>Sources:</span>
            {message.sources.map(doc => (
              <SourceTag key={doc.id} doc={doc} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

import { DOCUMENTS } from '../data/documents.js'
import styles from './WelcomeCard.module.css'

const DOT_COLORS = {
  blue:   '#185FA5',
  gold:   '#B8860B',
  coral:  '#993C1D',
  green:  '#3B6D11',
  purple: '#534AB7',
}

export default function WelcomeCard() {
  return (
    <div className={styles.card} role="complementary" aria-label="Welcome">
      <h2 className={styles.title}>Good day. How can I help?</h2>
      <p className={styles.body}>
        I have access to your institution's financial documents and can answer questions
        with precise, source-cited responses. Ask me about loan eligibility, compliance
        requirements, rate comparisons, or earnings data.
      </p>
      <div className={styles.docGrid} aria-label="Loaded documents">
        {Object.values(DOCUMENTS).map(doc => (
          <span key={doc.id} className={styles.badge}>
            <span
              className={styles.dot}
              style={{ background: DOT_COLORS[doc.colorClass] }}
              aria-hidden="true"
            />
            {doc.name.split('—')[0].trim()}
          </span>
        ))}
      </div>
    </div>
  )
}

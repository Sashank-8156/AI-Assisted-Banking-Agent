import { useState, useRef, useEffect } from 'react'
import styles from './InputBar.module.css'

export default function InputBar({ onSend, isLoading }) {
  const [text, setText] = useState('')
  const textareaRef = useRef(null)

  useEffect(() => {
    if (!isLoading && textareaRef.current) {
      textareaRef.current.focus()
    }
  }, [isLoading])

  const handleInput = (e) => {
    setText(e.target.value)
    const el = textareaRef.current
    if (el) {
      el.style.height = 'auto'
      el.style.height = Math.min(el.scrollHeight, 120) + 'px'
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleSend = () => {
    const trimmed = text.trim()
    if (!trimmed || isLoading) return
    onSend(trimmed)
    setText('')
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
    }
  }

  return (
    <div className={styles.bar}>
      <div className={styles.inputWrap}>
        <textarea
          ref={textareaRef}
          className={styles.textarea}
          value={text}
          onChange={handleInput}
          onKeyDown={handleKeyDown}
          placeholder="Ask a question about your financial documents…"
          rows={1}
          disabled={isLoading}
          aria-label="Message input"
        />
      </div>
      <button
        className={styles.sendBtn}
        onClick={handleSend}
        disabled={isLoading || !text.trim()}
        aria-label="Send message"
      >
        <i className={isLoading ? 'ti ti-loader-2' : 'ti ti-send'} aria-hidden="true" />
      </button>
    </div>
  )
}

import { DOCUMENTS } from '../data/documents.js'
import styles from './Sidebar.module.css'

const COLOR_MAP = {
  blue:   { bg: '#E6F1FB', color: '#185FA5' },
  gold:   { bg: 'rgba(212,160,23,0.1)', color: '#B8860B' },
  coral:  { bg: '#FAECE7', color: '#993C1D' },
  green:  { bg: '#EAF3DE', color: '#3B6D11' },
  purple: { bg: '#EEEDFE', color: '#534AB7' },
}

export default function Sidebar({ activeDocId, onSelectDoc }) {
  return (
    <aside className={styles.sidebar} aria-label="Document vault">
      <p className={styles.label}>Knowledge Vault</p>

      <button
        className={`${styles.docItem} ${activeDocId === 'all' ? styles.active : ''}`}
        onClick={() => onSelectDoc('all')}
        aria-pressed={activeDocId === 'all'}
      >
        <span
          className={styles.docIcon}
          style={{ background: 'rgba(212,160,23,0.1)' }}
          aria-hidden="true"
        >
          <i className="ti ti-database" style={{ color: 'var(--gold-mid)' }} />
        </span>
        <span className={styles.docInfo}>
          <span className={styles.docName}>All Documents</span>
          <span className={styles.docMeta}>5 files · Full context</span>
        </span>
      </button>

      <p className={styles.label} style={{ marginTop: 10 }}>Financial Docs</p>

      {Object.values(DOCUMENTS).map(doc => {
        const { bg, color } = COLOR_MAP[doc.colorClass] ?? COLOR_MAP.blue
        return (
          <button
            key={doc.id}
            className={`${styles.docItem} ${activeDocId === doc.id ? styles.active : ''}`}
            onClick={() => onSelectDoc(doc.id)}
            aria-pressed={activeDocId === doc.id}
          >
            <span className={styles.docIcon} style={{ background: bg }} aria-hidden="true">
              <i className={`ti ${doc.iconClass}`} style={{ color }} />
            </span>
            <span className={styles.docInfo}>
              <span className={styles.docName}>{doc.name}</span>
              <span className={styles.docMeta}>{doc.meta}</span>
            </span>
          </button>
        )
      })}
    </aside>
  )
}

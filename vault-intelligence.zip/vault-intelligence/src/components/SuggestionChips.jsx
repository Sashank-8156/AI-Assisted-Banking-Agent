import { SUGGESTED_QUESTIONS } from '../data/documents.js'
import styles from './SuggestionChips.module.css'

export default function SuggestionChips({ onSelect, visible }) {
  if (!visible) return null

  return (
    <div className={styles.chips} role="list" aria-label="Suggested questions">
      {SUGGESTED_QUESTIONS.map((q, i) => (
        <button
          key={i}
          className={styles.chip}
          onClick={() => onSelect(q)}
          role="listitem"
        >
          {q}
        </button>
      ))}
    </div>
  )
}

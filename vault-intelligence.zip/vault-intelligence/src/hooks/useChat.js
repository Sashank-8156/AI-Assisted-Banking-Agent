import { useState, useCallback } from 'react'
import { DOCUMENTS, ALL_DOCS_COMBINED } from '../data/documents.js'

const SYSTEM_PROMPT_BASE = `You are Vault Intelligence, a precise AI banking assistant for Fifth National Bank. 
You ONLY answer questions based on the financial documents provided below. 

Rules:
- Always cite specific figures, percentages, thresholds, and policy names from the documents
- If the answer is not in the documents, clearly state that and suggest which document might help
- Be concise but thorough — use short structured paragraphs
- Highlight key numbers naturally within sentences
- Never fabricate data, rates, or policies
- When referencing rates or thresholds, always include the exact figure
- Format responses for readability: use line breaks between distinct points

FINANCIAL DOCUMENTS:
`

export function useChat(activeDocId) {
  const [messages, setMessages] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)

  const getDocContext = useCallback(() => {
    if (activeDocId === 'all') return ALL_DOCS_COMBINED
    return DOCUMENTS[activeDocId]?.content ?? ALL_DOCS_COMBINED
  }, [activeDocId])

  const detectSources = useCallback((responseText) => {
    return Object.values(DOCUMENTS).filter(doc => {
      const lines = doc.content.split('\n').slice(0, 3).join(' ').toLowerCase()
      const keywords = lines.match(/[a-z]{5,}/g) ?? []
      return keywords.some(kw => responseText.toLowerCase().includes(kw))
    }).slice(0, 3)
  }, [])

  const sendMessage = useCallback(async (userText) => {
    if (!userText.trim() || isLoading) return

    const userMsg = { role: 'user', content: userText, id: Date.now() }
    const updatedMessages = [...messages, userMsg]
    setMessages(updatedMessages)
    setIsLoading(true)
    setError(null)

    const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY
    if (!apiKey || apiKey === 'your_anthropic_api_key_here') {
      setError('Please add your Anthropic API key to the .env file.')
      setIsLoading(false)
      return
    }

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1024,
          system: SYSTEM_PROMPT_BASE + getDocContext(),
          messages: updatedMessages.map(({ role, content }) => ({ role, content }))
        })
      })

      if (!response.ok) {
        const err = await response.json()
        throw new Error(err.error?.message ?? `API error ${response.status}`)
      }

      const data = await response.json()
      const replyText = data.content?.map(b => b.text ?? '').join('') ?? 'No response received.'
      const sources = detectSources(replyText)

      const assistantMsg = {
        role: 'assistant',
        content: replyText,
        sources,
        id: Date.now() + 1
      }

      setMessages(prev => [...prev, assistantMsg])
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }, [messages, isLoading, getDocContext, detectSources])

  const clearChat = useCallback(() => {
    setMessages([])
    setError(null)
  }, [])

  return { messages, isLoading, error, sendMessage, clearChat }
}
